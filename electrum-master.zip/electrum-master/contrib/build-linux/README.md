Source tarballs
===============

✗ _This script does not produce reproducible output (yet!)._

1. Prepare python dependencies used by Electrum.

    ```
    contrib/make_packages
    ```

2. Create source tarball.

    ```
    contrib/make_tgz
    ```
